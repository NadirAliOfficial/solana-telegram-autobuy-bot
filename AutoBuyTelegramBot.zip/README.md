# Solana Telegram AutoBuy Bot

This Python bot listens to private Telegram channels or groups for trading signals (contract addresses) and prepares for automated buys on the Solana blockchain. It includes:

- Telegram signal integration via Telethon
- Wallet setup using Phantom/private key
- Basic config for buy amount and slippage
- Ready for expansion with stop-loss and auto-sell logic
